#  TinyUSB Mouse and Keyboard Library Changelog

## 0.1.3 - 2024.01.11

- Renamed USBDevice to TinyUSBDevice because Adafruit renamed it

## 0.1.2 - 2020.04.26

- Merged PR #1

## 0.1.1 - 2020.04.17

- Complete Redesign to combine mouse and keyboard in the same library

## 0.1.0 - 2020.04.14

- Initial beta release
